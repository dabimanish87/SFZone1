<?php 

$request_data = json_decode(file_get_contents("php://input"));

$username = $request_data->username;
$password = $request_data->password;

// $username = "test1";
// $password = "test";

$mysqli = new mysqli("localhost","id12801856_root","O1PMfUR+&A!WeBBw","id12801856_sfzone_test");

$result = mysqli_query($mysqli,"select * from logintable where username = '".$username."' and password = '".$password."'");

$tt = mysqli_fetch_assoc($result);

if($tt == null || sizeof($tt) == 0)
{
    // echo "failed";
	http_response_code(200);
	$error = (object) [
        'error' => 'invalid credentials'
    ];
	echo json_encode($error);
}
else
{
	http_response_code(200);
	echo json_encode($tt);
}

?>