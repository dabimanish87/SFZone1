<?php 

$request_data = json_decode(file_get_contents("php://input"));

$response = $request_data->qr_name;

$mysqli = new mysqli("localhost","id12801856_root","O1PMfUR+&A!WeBBw","id12801856_sfzone_test");

$mysql1 = new mysqli("localhost","id12801856_root","O1PMfUR+&A!WeBBw","id12801856_sfzone_test");

$result = mysqli_query($mysqli,"select * from qrcode where qr_details = '".$response."'");

$row = $result->fetch_row();

if($row == null || sizeof($row) == 0)
{
  	echo "Not able to mark present";
}
else
{
    // $result = mysqli_query($mysql1,"insert into attendance (sub_name, date, class_name, attendance, user_id) values ('s','2020-02-02','c',1,4)");
	$result = mysqli_query($mysql1,"insert into attendance (sub_name, date, class_name, attendance, user_id) values ('$row[1]','$row[2]', '$row[3]', 1,$request_data->user_id)");
	
	if ($result == 'true') {
	echo "Attendance Stored Successfully.";    
	} else {
	    echo "Attendance couldn't stored.";
	}
	
}

?>

