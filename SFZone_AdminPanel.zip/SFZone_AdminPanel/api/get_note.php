<?php
$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test');

$id=$_GET['id'];

$sql = "SELECT * FROM material_file where file_type='notes' AND id='$id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. "<br>" .  "file_name: " . $row["file_name"]. "<br> ". "file_url:" . $row["file_url"]. " <br>" . 
        "file_icon: " . $row["file_icon"]. "<br> " ."sub_name: " . $row["sub_name"]. " " .    "<br>"."<br>";
    }
} else {
    echo "0 results";
}
	
?>