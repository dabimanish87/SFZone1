<?php 

$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test');

	$stmt = $conn->prepare("SELECT id, name, place, date, time FROM event ;");
	
	$stmt->execute();
	
	//binding results to the query 
	$stmt->bind_result($id, $name, $place, $date, $time);
	
	$products = array(); 
	
	//traversing through all the result 
	while($stmt->fetch()){
		$temp = array();
		$temp['id'] = $id; 
		$temp['name'] = $name; 
		$temp['place'] = $place; 
		$temp['date'] = $date; 
		$temp['time'] = $time; 
		
		array_push($products, $temp);
	
	}
	
	class Notes {
	    public $list;
	}
	
	$notes = new Notes();
	$notes->list = $products;
	
	//displaying the result in json format 
	echo json_encode($notes);