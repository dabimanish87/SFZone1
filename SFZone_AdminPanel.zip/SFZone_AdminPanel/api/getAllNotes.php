<?php 

$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test');

	$stmt = $conn->prepare("SELECT id,file_name,file_url,file_icon,sub_name FROM material_file WHERE file_type='notes';");
	
	$stmt->execute();
	
	//binding results to the query 
	$stmt->bind_result($id, $file_name, $file_url, $file_icon, $sub_name);
	
	$products = array(); 
	
	//traversing through all the result 
	while($stmt->fetch()){
		$temp = array();
		$temp['id'] = $id; 
		$temp['file_name'] = $file_name; 
		$temp['file_url'] = $file_url; 
		$temp['file_icon'] = $file_icon; 
		$temp['sub_name'] = $sub_name; 
		
		array_push($products, $temp);
	
	}
	
	class Notes {
	    public $list;
	}
	
	$notes = new Notes();
	$notes->list = $products;
	
	//displaying the result in json format 
	echo json_encode($notes);