<?php 

$request_data = json_decode(file_get_contents("php://input"));

$start_date = $request_data->start_date;
$end_date = $request_data->end_date;
$user_id = $request_data->user_id;

$mysqli = new mysqli("localhost","id12801856_root","O1PMfUR+&A!WeBBw","id12801856_sfzone_test");

$stmt = $mysqli->prepare("SELECT sub_name, count(*) as total_present_days FROM attendance WHERE date BETWEEN '$start_date' AND '$end_date' AND user_id IN ($user_id) GROUP BY sub_name;");
$stmt->execute();

$stmt->bind_result($sub_name,$total_present_days);
	
	$products = array(); 
	
	//traversing through all the result 
	while($stmt->fetch()){
		$temp = array();
		$temp['sub_name'] = $sub_name; 
		$temp['total_present_days'] = $total_present_days;
		
		array_push($products, $temp);
	
	}
	
	class Notes {
	    public $list;
	}
	
	$notes = new Notes();
	$notes->list = $products;
	
	//displaying the result in json format 
	echo json_encode($notes);