<?php
include 'FilesLogicNotes.php'?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="style.css">
    <title>SF Zone</title>
    <link rel="icon" href="login.png" type="image/x-icon">
  </head>
  <body>
       <?php
       require ("sidebar.php");
    ?>
    <div class="container">
      <div class="row">

        <form action="" method="post" enctype="multipart/form-data" >
          <h3>Upload Notes</h3>
          <div class="form-group"> 
                
                <input id="sub_name" type="text" class="form-control" name="sub_name" placeholder="Enter Subject Name">
                                                           
            </div><br>
          <input type="file" name="myfile"> <br>
          <button type="submit" name="save">upload</button>
        </form>
      </div>
    </div>
  </body>
</html>
