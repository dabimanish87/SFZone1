<?php

// connect to the database
$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test');

// Uploads files
if (isset($_POST['save'])) { // if save button on the form is clicked
    // name of the uploaded file
    $filename = $_FILES['myfile']['name'];
    $size = $_FILES['myfile']['size'];
    $file_type="assignment";
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    $file_url="http://kamal002.000webhostapp.com/sfzone/uploaded_materials/"."$filename";
    
      if($extension == "zip")
    {
        $file_icon="zip";
    }
    elseif ($extension == "pdf")
    {
        $file_icon="pdf";
    }
    elseif($extension == "docx" || $extension == "doc")
    {
        $file_icon="doc";
    }
    elseif($extension == "jpg" || $extension == "jpeg")
    {
        $file_icon="jpg";
    }
    elseif($extension == "png")
    {
        $file_icon="png";
    }
      elseif($extension == "xls")
    {
        $file_icon="xls";
    }
    else
    {
        $file_icon="default";   
    }
    
    
    $sub_name = $_POST['sub_name'];
    $uploaded_date=date("y-m-d");

    $user_id=2;
    
    // destination of the file on the server
    $destination = '../uploaded_materials/' . $filename;

    // get the file extension
    

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    

     if (!in_array($extension, ['zip', 'pdf', 'docx', 'doc','jpg', 'jpeg', 'png', 'xls'])) {
        echo "You file extension must be .zip, .pdf, .docx, doc, jpg, jpeg, png, xls";
    } elseif ($_FILES['myfile']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO material_file (file_name, file_size, file_type, file_url, file_icon, user_id, sub_name, uploaded_date) VALUES ('$filename',$size,'$file_type','$file_url','$file_icon',$user_id,'$sub_name','$uploaded_date')";
            if (mysqli_query($conn, $sql)) {
                echo "File uploaded successfully";
            }
        } else {
            echo "Failed to upload file.";
        }
    }
}