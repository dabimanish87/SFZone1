<?php
$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test'); // Establishing Connection with Server

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$name = $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];
$mobile = $_POST['mobile'];

$sql = "INSERT INto logintable (username, password, mobile, name) values ('$username','$password', '$mobile', '$name');";
            if (mysqli_query($conn, $sql)) {
                echo "User added successfully";
            }
        } else {
            echo "Failed to add user.";
        }
?>