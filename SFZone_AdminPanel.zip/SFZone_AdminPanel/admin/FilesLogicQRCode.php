<?php

$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test');
require_once 'phpqrcode/qrlib.php';

if (isset($_POST['save'])) {

$path = '../uploaded_materials/';

$sub_name = $_POST['sub_name'];
$date = $_POST['date'];
$class_name = $_POST['class_name'];

$qr_name = $date."_".$sub_name."_".$class_name;
$file = $path.$qr_name;

$qrcode = $date."_".$sub_name."_".$class_name;

$class_name = $_POST['class_name'];
$qr_url="http://kamal002.000webhostapp.com/sfzone/uploaded_materials/"."$qr_name";

$user_id=2;

$uploaded_date=date("y-m-d");

QRcode::png("$qrcode","$file",'L',10);

echo"<center><img src = '".$file."'></center>";

$sql = "INSERT INTO qrcode (sub_name, date, class_name,qr_details, qr_url, user_id, uploaded_date) VALUES ('$sub_name','$date','$class_name','$qr_name','$qr_url',$user_id,'$uploaded_date')";
mysqli_query($conn, $sql);

/*$sql = "INSERT INTO qrcode (sub_name, date, class_name,qr_details, qr_url, user_id, uploaded_date) VALUES ('$sub_name',$date,'$class_name','abcdef',$qr_url',$user_id,'$uploaded_date')";
            if (mysqli_query($conn, $sql)) {
                echo "QRCode uploaded successfully";
            }
        } else {
            echo "Failed to upload QRCode.";*/
}
?>