<?php
$conn = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test'); // Establishing Connection with Server

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$name = $_POST['name'];
$place = $_POST['place'];
$date = $_POST['date'];
$time = $_POST['time'];
$user_id=2;

$sql = "INSERT INTO event (name, place, date, time, user_id) values ('$name','$place', '$date', '$time', '$user_id');";
            if (mysqli_query($conn, $sql)) {
                echo "Event added successfully.";
            }
         else {
            echo "Failed to add event.";
        }
}        
?>