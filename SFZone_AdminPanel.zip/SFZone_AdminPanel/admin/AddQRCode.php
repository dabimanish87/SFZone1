<?php include 'FilesLogicQRCode.php'?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="style.css">
    <title>Files Upload and Download</title>
  </head>
  <body>
        <?php
       require ("sidebar.php");
    ?>
    <div class="container">
      <div class="row">

        <form action="" method="post" enctype="multipart/form-data" >
            <h3>Upload QRCode</h3><br>
            
            <div class="form-group"> 
                <input id="sub_name" type="text" class="form-control" name="sub_name" placeholder="Enter Subject Name">
            </div><br>
            

            <div class="form-group"> 
                <input id="class_name" type="text" class="form-control" name="class_name" placeholder="Enter Class">
            </div><br>
                      
            <div class="form-group"> 
                <input id="date" type="text" class="form-control" name="date" placeholder="Enter date (YYYY-MM-DD)">
            </div><br>
 
            

          
          <button type="submit" name="save">submit</button>
        </form>
      </div>
    </div>
  </body>
</html>
