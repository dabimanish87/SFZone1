<!DOCTYPE html>
<html lang="en">

<head>
    <title>SF Zone</title>
    <!-- HTML5 Shim and Respond.js IE11 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 11]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Free Datta Able Admin Template come up with latest Bootstrap 4 framework with basic components, form elements and lots of pre-made layout options" />
    <meta name="keywords" content="admin templates, bootstrap admin templates, bootstrap 4, dashboard, dashboard templets, sass admin templets, html admin templates, responsive, bootstrap admin templates free download,premium bootstrap admin templates, datta able, datta able bootstrap admin template, free admin theme, free dashboard template"/>
    <meta name="author" content="CodedThemes"/>

    <!-- Favicon icon -->
    <link rel="icon" href="login.png" type="image/x-icon">
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/fontawesome-all.min.css">
    <!-- animation css -->
    <link rel="stylesheet" href="assets/plugins/animation/css/animate.min.css">
    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->
     <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar">
        <div class="navbar-wrapper">
            <div class="navbar-brand header-logo">
                <a href="index.php" class="b-brand">
                    <img src="login.png" width="40" height="50"/>
                     
                    <span class="b-title">SF Zone</span>
                </a>
                <!-- <a class="mobile-menu" id="mobile-collapse"><span></span></a> -->
            </div>
            <div class="navbar-content scroll-div">
                <ul class="nav pcoded-inner-navbar">
                    <li class="nav-item pcoded-menu-caption">
                        <label></label>
                    </li>
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item active">
                        <a href="index.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>
                    <li class="nav-item pcoded-menu-caption">
                        <label>INTERFACE</label>
                    </li>
                    <li data-username="basic components Button Alert Badges breadcrumb Paggination progress Tooltip popovers Carousel Cards Collapse Tabs pills Modal Grid System Typography Extra Shadows Embeds" class="nav-item pcoded-hasmenu">
                        <a href="javascript:" class="nav-link "><span class="pcoded-micon"><i class="feather icon-box"></i></span><span class="pcoded-mtext">User</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="AddUser.php" class="">Add</a></li>
                            <li class=""><a href="ViewUser.php" class="">View</a></li>
                            <!-- <li class=""><a href="http://localhost/Kamal/updateuser.php" class="">Update</a></li> -->
                             <!-- <li class=""><a href="http://localhost/Kamal/deleteuser.php" class="">Remove</a></li> -->
                            
                            



                            
                        </ul>
                    </li><br>
                    <li data-username="basic components Button Alert Badges breadcrumb Paggination progress Tooltip popovers Carousel Cards Collapse Tabs pills Modal Grid System Typography Extra Shadows Embeds" class="nav-item pcoded-hasmenu">
                        <a href="javascript:" class="nav-link "><span class="pcoded-micon"><i class="feather icon-box"></i></span><span class="pcoded-mtext">Upload</span></a>
                        <ul class="pcoded-submenu">
                            
                            <li class=""><a href="AddQRCode.php" class="">QR Code</a></li>
                            <li class=""><a href="AddNotes.php" class="">Notes</a></li>
                            <li class=""><a href="AddAssignment.php" class="">Assignment</a></li>
                            <li class=""><a href="AddTimetable.php" class="">Time Table</a></li>
                            <li class=""><a href="AddAttendance.php" class="">Attendance Report</a></li>
                            <li class=""><a href="AddEvent.php" class="">Events</a></li>

                        </ul>
                    </li><br>
                    <li data-username="basic components Button Alert Badges breadcrumb Paggination progress Tooltip popovers Carousel Cards Collapse Tabs pills Modal Grid System Typography Extra Shadows Embeds" class="nav-item pcoded-hasmenu">
                        <a href="javascript:" class="nav-link "><span class="pcoded-micon"><i class="feather icon-box"></i></span><span class="pcoded-mtext">View</span></a>
                        <ul class="pcoded-submenu">
                            
                            <li class=""><a href="ViewQRCode.php" class="">QR Code</a></li>
                            <li class=""><a href="ViewNotes.php" class="">Notes</a></li>
                            <li class=""><a href="ViewAssignment.php" class="">Assignment</a></li>
                            <li class=""><a href="ViewTimetable.php" class="">Time Table</a></li>
                            <li class=""><a href="ViewAttendance.php" class="">Attendance Report</a></li>
                            <li class=""><a href="ViewEvent.php" class="">Events</a></li>
                            
                        </ul>
                    </li><br>
                       
                    <!-- <li data-username="form elements advance componant validation masking wizard picker select" class="nav-item">
                        <a href="http://localhost/hachthone/dustbinview.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-file-text"></i></span><span class="pcoded-mtext">SmartBin</span></a>
                    </li> -->
                    <!-- <li data-username="form elements advance componant validation masking wizard picker select" class="nav-item">
                        <a href="" class="nav-link "><span class="pcoded-micon"><i class="feather icon-file-text"></i></span><span class="pcoded-mtext">Feedback</span></a>
                    </li> -->
                   
                    
                   
                   
                   
                    <li data-username="basic components Button Alert Badges breadcrumb Paggination progress Tooltip popovers Carousel Cards Collapse Tabs pills Modal Grid System Typography Extra Shadows Embeds" class="nav-item pcoded-hasmenu">
                        <a href="signin.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-box"></i></span><span class="pcoded-mtext">LogOut</span></a>
                        <!-- <ul class="pcoded-submenu">
                            <li class=""><a href="" class="">view</a></li>
                            <li class=""><a href="" class="">Aproov</a></li>
                            <li class=""><a href="" class="">Cancle</a></li>
                        </ul> -->
                    </li>                  
                
                
             

    </div>

            </div>

        </div>
    </nav>
</body>

<script src="assets/js/vendor-all.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/pcoded.min.js"></script>
</html>
    <!-- [ navigation menu ] end -->
