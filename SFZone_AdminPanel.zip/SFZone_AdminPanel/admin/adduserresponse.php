<?php

    require("conncet.php");
    // require("sidebar.php");
    //require("topbar.php");

    $user_data=json_decode(file_get_contents("php://input"));

    $del="insert into logintable (name, username, password, mobile) values ('$user_data->name', '$user_data->username','$user_data->password', $user_data->mobile)";
    $response = mysqli_query($conn, $del);
    if(mysqli_query($conn,$del))
    {
      echo "New user added succesfull";
    }
    else
    {
      echo "error";
    }

//echo "hi";
    //$user =mysqli_fetch_assoc($response);
    //print_r($user);

?>
<html>
<head>
    <title>SF Zone</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Free Datta Able Admin Template come up with latest Bootstrap 4 framework with basic components, form elements and lots of pre-made layout options" />
    <meta name="keywords" content="admin templates, bootstrap admin templates, bootstrap 4, dashboard, dashboard templets, sass admin templets, html admin templates, responsive, bootstrap admin templates free download,premium bootstrap admin templates, datta able, datta able bootstrap admin template, free admin theme, free dashboard template"/>
    <meta name="author" content="CodedThemes"/>

    <!-- Favicon icon -->
    <link rel="icon" href="logo.png" type="image/x-icon">
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/fontawesome-all.min.css">
    <!-- animation css -->
    <link rel="stylesheet" href="assets/plugins/animation/css/animate.min.css">
    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
<h3><center>User successfully added.</center></h3>

</body>
</html>