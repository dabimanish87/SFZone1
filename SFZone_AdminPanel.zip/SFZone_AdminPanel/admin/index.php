<?php
  require("conncet.php");

    $sql = "SELECT count(*) from logintable";
    $response = mysqli_query($conn, $sql);
    $row =mysqli_fetch_assoc($response);
    $totaluser = $row['count(*)'];
    
    $conn1 = mysqli_connect('localhost', 'id12801856_root','O1PMfUR+&A!WeBBw','id12801856_sfzone_test');
    $sql1="SELECT count(*) from material_file";
    $response1 = mysqli_query($conn1, $sql1);
    $row1 =mysqli_fetch_assoc($response1);
    $totaluser1 = $row1['count(*)'];   
 

    $sql2="SELECT count(*) from material_file";
    $response2 = mysqli_query($conn1, $sql2);
    $row2 =mysqli_fetch_assoc($response2);
    $totaluser2 = $row2['count(*)'];
    
    $sql3="SELECT count(*) from event";
    $response3 = mysqli_query($conn1, $sql3);
    $row3 =mysqli_fetch_assoc($response3);
    $totaluser3 = $row3['count(*)'];
 
 //$totaluser3=$totaluser1+$totaluser2;
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>SF Zone</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Free Datta Able Admin Template come up with latest Bootstrap 4 framework with basic components, form elements and lots of pre-made layout options" />
    <meta name="keywords" content="admin templates, bootstrap admin templates, bootstrap 4, dashboard, dashboard templets, sass admin templets, html admin templates, responsive, bootstrap admin templates free download,premium bootstrap admin templates, datta able, datta able bootstrap admin template, free admin theme, free dashboard template"/>
    <meta name="author" content="CodedThemes"/>

    <!-- Favicon icon -->
    <link rel="icon" href="login.png" type="image/x-icon">
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/fontawesome-all.min.css">
    <!-- animation css -->
    <link rel="stylesheet" href="assets/plugins/animation/css/animate.min.css">
    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body background="assets/images/login.png" >
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <?php
       require ("sidebar.php");
    ?>

        <?php
         require ("topbar.php");
    ?> 
  
          

    <!-- [ Main Content ] start -->
 <div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
            <!-- [ breadcrumb ] start -->
            <!-- [ breadcrumb ] end -->
            <div class="main-body">
             <div class="page-wrapper">
            <!-- [ Main Content ] start -->
                <!-- <div class="row"> -->
                <!--[ daily sales section ] start-->
                <!-- <div class="col-md-6 col-xl-4">
                    <div class="card daily-sales">
                        <div class="card-block">
                            <div class="row d-flex align-items-center">
                            <div class="col-9">
                             <h6 class="mb-4">Total Users:</h6>
                             <h3 class="f-w-300 d-flex align-items-center m-b-0"></h3>
                            
                            
                            </div>
                             <div class="col-3 text-right">
                              <p class="m-b-0"></p>
                            </div> 
                            </div>
                            </div>
                            </div>
                            </div> -->
                            <!--[ daily sales section ] end-->
                            <!--[ Monthly  sales section ] starts-->
                            <!-- <div class="col-md-6 col-xl-4">
                            <div class="card Monthly-sales">
                            <div class="card-block">
                             <h6 class="mb-4">Ardino Kit:</h6>
                            
                             <h3 class="f-w-300 d-flex align-items-center m-b-0"></h3>
                            
                             <div class="col-9">
                             <h3 class="f-w-300 d-flex align-items-center  m-b-0"> -->
                             <!--<i class="feather icon-arrow-down text-c-red f-30 m-r-10"></i>-->
                             <!-- </div>
                             <div class="col-3 text-right">
                             <p class="m-b-0"></p>
                             </div>
                             </div>
                             </div>
                             </div>
                             </div> -->

                             <!-- <div class="col-md-6 col-xl-4">
                             <div class="card yearly-sales">
                              <div class="card-block">
                              <h6 class="mb-4">Pending Request:</h6>
                              <div class="row d-flex align-items-center">
                                <div class="col-9">
                                    <h3 class="f-w-300 d-flex align-items-center  m-b-0"</h3>
                                </div>
                                <div class="col-3 text-right">
                                 <p class="m-b-0"></p>
                                </div>
                            </div>
                            </div>
                            </div>
                            </div> -->

                            <div class="row">
                                <!--[ daily sales section ] start-->
                                <div class="col-md-6 col-xl-4">
                                    <div class="card daily-sales">
                                        <div class="card-block">
                                          <h6 class="mb-4">Total Students:</h6>
                                           

                                            <div class="row d-flex align-items-center">
                                                <div class="col-9">
                                                    <h3 class="f-w-300 d-flex align-items-center m-b-0"> <!--<i class="feather icon-arrow-up text-c-green f-30 m-r-10"></i>--> <img class="rounded-circle m-r-10" style="width:40px;" src="assets/images/user/student.png"><?=$totaluser?></h3>
                                                </div>

                                                <!-- <div class="col-3 text-right">
                                                    <p class="m-b-0">67%</p>
                                                </div> -->
                                            </div>
                                            <!-- <div class="progress m-t-30" style="height: 7px;">
                                                <div class="progress-bar progress-c-theme" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-xl-4">
                                    <div class="card daily-sales">
                                        <div class="card-block">
                                          <h6 class="mb-4">Total Faculty:</h6>
                                           

                                            <div class="row d-flex align-items-center">
                                                <div class="col-9">
                                                    <h3 class="f-w-300 d-flex align-items-center m-b-0"> <!--<i class="feather icon-arrow-up text-c-green f-30 m-r-10"></i>--> <img class="rounded-circle m-r-10" style="width:40px;" src="assets/images/user/faculty1.png"><?=$totaluser?></h3>
                                                </div>

                                                <!-- <div class="col-3 text-right">
                                                    <p class="m-b-0">67%</p>
                                                </div> -->
                                            </div>
                                            <!-- <div class="progress m-t-30" style="height: 7px;">
                                                <div class="progress-bar progress-c-theme" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-xl-4">
                                    <div class="card daily-sales">
                                        <div class="card-block">
                                          <h6 class="mb-4">Total Files:</h6>
                                           

                                            <div class="row d-flex align-items-center">
                                                <div class="col-9">
                                                    <h3 class="f-w-300 d-flex align-items-center m-b-0"> <!--<i class="feather icon-arrow-up text-c-green f-30 m-r-10"></i>--> <img class="rounded-circle m-r-10" style="width:40px; height:40px;" src="assets/images/browser/default.png"><?=$totaluser2?></h3>
                                                </div>

                                                <!-- <div class="col-3 text-right">
                                                    <p class="m-b-0">67%</p>
                                                </div> -->
                                            </div>
                                            <!-- <div class="progress m-t-30" style="height: 7px;">
                                                <div class="progress-bar progress-c-theme" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <div class="col-md-6 col-xl-4">
                                    <div class="card daily-sales">
                                        <div class="card-block">
                                          <h6 class="mb-4">Total Events:</h6>
                                           

                                            <div class="row d-flex align-items-center">
                                                <div class="col-9">
                                                    <h3 class="f-w-300 d-flex align-items-center m-b-0"> <!--<i class="feather icon-arrow-up text-c-green f-30 m-r-10"></i>--> <img class="rounded-circle m-r-10" style="width:40px; height:40px;" src="assets/images/browser/event.png"><?=$totaluser3?></h3>
                                                </div>

                                                <!-- <div class="col-3 text-right">
                                                    <p class="m-b-0">67%</p>
                                                </div> -->
                                            </div>
                                            <!-- <div class="progress m-t-30" style="height: 7px;">
                                                <div class="progress-bar progress-c-theme" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                                <!--[ daily sales section ] end-->
                                <!--[ Monthly  sales section ] starts-->
                                <!--[ Monthly  sales section ] end-->
                                <!--[ year  sales section ] starts-->
                              
                            <!--[ Monthly  sales section ] end-->
                            <!--[ year  sales section ] starts-->
                            

                               <!-- <br><br> <div class="col-xl-4 col-md-6">
                                    <div class="card user-list">
                                        <div class="card-header">
                                            <h5>Rating</h5>
                                        </div>
                                        <div class="card-block">
                                            <div class="row align-items-center justify-content-center m-b-20">
                                                <div class="col-6">
                                                    <h2 class="f-w-300 d-flex align-items-center float-left m-0">4.7 <i class="fas fa-star f-10 m-l-10 text-c-yellow"></i></h2>
                                                </div>
                                                <div class="col-6">
                                                    <h6 class="d-flex  align-items-center float-right m-0">0.4 <i class="fas fa-caret-up text-c-green f-22 m-l-10"></i></h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xl-12">
                                                    <h6 class="align-items-center float-left"><i class="fas fa-star f-10 m-r-10 text-c-yellow"></i>5</h6>
                                                    <h6 class="align-items-center float-right">384</h6>
                                                    <div class="progress m-t-30 m-b-20" style="height: 6px;">
                                                        <div class="progress-bar progress-c-theme" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <h6 class="align-items-center float-left"><i class="fas fa-star f-10 m-r-10 text-c-yellow"></i>4</h6>
                                                    <h6 class="align-items-center float-right">145</h6>
                                                    <div class="progress m-t-30  m-b-20" style="height: 6px;">
                                                        <div class="progress-bar progress-c-theme" role="progressbar" style="width: 35%;" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <h6 class="align-items-center float-left"><i class="fas fa-star f-10 m-r-10 text-c-yellow"></i>3</h6>
                                                    <h6 class="align-items-center float-right">24</h6>
                                                    <div class="progress m-t-30  m-b-20" style="height: 6px;">
                                                        <div class="progress-bar progress-c-theme" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <h6 class="align-items-center float-left"><i class="fas fa-star f-10 m-r-10 text-c-yellow"></i>2</h6>
                                                    <h6 class="align-items-center float-right">1</h6>
                                                    <div class="progress m-t-30  m-b-20" style="height: 6px;">
                                                        <div class="progress-bar progress-c-theme" role="progressbar" style="width: 10%;" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <h6 class="align-items-center float-left"><i class="fas fa-star f-10 m-r-10 text-c-yellow"></i>1</h6>
                                                    <h6 class="align-items-center float-right">0</h6>
                                                    <div class="progress m-t-30  m-b-20" style="height: 6px;">
                                                        <div class="progress-bar" role="progressbar" style="width:0;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->

                                <!-- [ statistics year chart ] start -->
                                <div class="col-xl-4 col-md-6">
                                    
                                    </div>
                                    
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              

</body>
</html>
