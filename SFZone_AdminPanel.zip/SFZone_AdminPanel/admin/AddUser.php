<?php
include 'FilesLogicUser.php';
require("sidebar.php");
require("conncet.php");


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>SF Zone</title>
    <link rel="icon" href="login.png" type="image/x-icon">
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Datta Able Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
    <meta name="keywords" content="admin templates, bootstrap admin templates, bootstrap 4, dashboard, dashboard templets, sass admin templets, html admin templates, responsive, bootstrap admin templates free download,premium bootstrap admin templates, datta able, datta able bootstrap admin template, free admin theme, free dashboard template"/>
    <meta name="author" content="CodedThemes"/>

    <!-- Favicon icon -->
     <link rel="icon" href="login.png" type="image/x-icon">
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/fontawesome-all.min.css">
    <!-- animation css -->
    <link rel="stylesheet" href="assets/plugins/animation/css/animate.min.css">
    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <!-- [ Pre-loader ] start -->
    
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->
   

   

    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">
            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <!-- [ breadcrumb ] start -->
                    <div class="page-header">
                        <div class="page-block">
                            <div class="row align-items-center">
                                <div class="col-md-12">
                                    <div class="page-header-title">
                                        <h5 class="m-b-10">Add User</h5>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- [ breadcrumb ] end -->
                    <div class="main-body">
                        <div class="page-wrapper">
                            <!-- [ Main Content ] start -->
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="card">

                                        <div class="card-body">
                                            <!-- <h5>Form controls</h5> -->
                                            <hr>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <form method="POST">
                                                      
                                                        <div class="form-group"> 
                                                            <label for="exampleInputEmail1">Name</label>
                                                            <input id="user_name" type="text" class="form-control" name="name" placeholder="Enter full name">
                                                            <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleInputPassword1">Username</label>
                                                            <input id="user_username" type="text" class="form-control"name="username" placeholder="Enter username">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleInputPassword1">Password</label>
                                                            <input id="user_password" type="Password" class="form-control" name="password"  placeholder="Enter password">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleInputPassword1">Mobile Number</label>
                                                            <input id="user_mobile" type="text" class="form-control" name="mobile" placeholder="Enter mobile number">
                                                        </div>
                                                        <!-- <div class="form-group form-check">
                                                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                            <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                                        </div> -->
                                                        <input type="submit" name="submit" class="btn btn-primary" ></button>
                                                        
                                                    </form>
                                                </div>
                                               
                                            </div>
                                          


</body>
</html>
