<?php

$conn = mysqli_connect("localhost", "id12801856_root","O1PMfUR+&A!WeBBw","id12801856_sfzone_test");

?>